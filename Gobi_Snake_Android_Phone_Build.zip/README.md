# Gobi Snake — Android project

Your uploaded portrait is included as `assets/snake_head.png` and used as the snake's head.
Targets alternate automatically: Old Monk, then grapes, then Old Monk. The game has touchscreen
arrow controls, score tracking, and a locally saved high score.

## Build an Android APK

Buildozer is most reliable on Ubuntu Linux (or WSL2 with Ubuntu). It downloads the Android SDK/NDK
on the first build, so an internet connection is required.

```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip python3-venv \
  build-essential autoconf libtool pkg-config zlib1g-dev libncurses5-dev \
  libncursesw5-dev cmake libffi-dev libssl-dev
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install buildozer cython
buildozer android debug
```

The APK will be created in `bin/`. Transfer it to your Android phone and install it.
Allow installation from that file source if Android asks.

## Run on macOS for testing

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install kivy
python main.py
```

## Customize your face

Replace `assets/snake_head.png` with a square PNG, keeping the same filename.
