import os, random, json
from kivy.app import App
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle, Line, Ellipse, RoundedRectangle
from kivy.core.image import Image as CoreImage
from kivy.metrics import dp
from kivy.properties import NumericProperty
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.widget import Widget
from kivy.uix.button import Button
from kivy.uix.label import Label

N = 20

class Board(Widget):
    score = NumericProperty(0)
    high = NumericProperty(0)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.snake = [(5, 8), (4, 8), (3, 8), (2, 8)]
        self.direction = (1, 0)
        self.pending = (1, 0)
        self.target = 0  # 0 Old Monk, 1 grapes
        self.food = (14, 8)
        self.running = False
        self.message = "Press PLAY to start"
        self.bind(pos=self.draw, size=self.draw)
        self.face = None
        try:
            self.face = CoreImage(os.path.join(os.path.dirname(__file__),
                                  "assets", "snake_head.png")).texture
        except Exception:
            pass
        Clock.schedule_once(lambda *_: self.load_score(), 0)

    def load_score(self):
        try:
            with open(os.path.join(App.get_running_app().user_data_dir, "score.json")) as f:
                self.high = json.load(f).get("high", 0)
        except Exception:
            self.high = 0

    def save_score(self):
        try:
            with open(os.path.join(App.get_running_app().user_data_dir, "score.json"), "w") as f:
                json.dump({"high": int(self.high)}, f)
        except Exception:
            pass

    def start(self, *_):
        Clock.unschedule(self.step)
        self.snake = [(5, 8), (4, 8), (3, 8), (2, 8)]
        self.direction = self.pending = (1, 0)
        self.target = 0
        self.score = 0
        self.message = "Collect the target!"
        self.place_food()
        self.running = True
        Clock.schedule_interval(self.step, .17)
        self.draw()

    def pause(self, *_):
        if self.running:
            self.running = False
            Clock.unschedule(self.step)
            self.message = "Paused"

    def turn(self, d):
        if d != (-self.direction[0], -self.direction[1]):
            self.pending = d

    def place_food(self):
        free = [(x, y) for x in range(N) for y in range(N) if (x, y) not in self.snake]
        self.food = random.choice(free)

    def step(self, dt):
        if not self.running:
            return
        self.direction = self.pending
        x, y = self.snake[0]
        head = (x + self.direction[0], y + self.direction[1])
        if head[0] < 0 or head[0] >= N or head[1] < 0 or head[1] >= N or head in self.snake[:-1]:
            self.running = False
            Clock.unschedule(self.step)
            self.message = "GAME OVER! Tap PLAY again."
            self.draw()
            return
        self.snake.insert(0, head)
        if head == self.food:
            self.score += 1
            if self.score > self.high:
                self.high = self.score
                self.save_score()
            self.target = 1 - self.target
            self.message = "TARGET SWITCHED! " + ("GRAPES 🍇" if self.target else "OLD MONK 🍾")
            self.place_food()
        else:
            self.snake.pop()
        self.draw()

    def draw(self, *_):
        self.canvas.clear()
        cell = max(1, min(self.width, self.height) / N)
        bw = cell * N
        ox = self.x + (self.width - bw) / 2
        oy = self.y + (self.height - bw) / 2
        with self.canvas:
            Color(.008, .025, .035, 1)
            Rectangle(pos=self.pos, size=self.size)
            Color(.04, .17, .18, 1)
            for i in range(N + 1):
                Line(points=[ox+i*cell, oy, ox+i*cell, oy+bw], width=.5)
                Line(points=[ox, oy+i*cell, ox+bw, oy+i*cell], width=.5)
            fx, fy = self.food
            cx, cy = ox+(fx+.5)*cell, oy+(fy+.5)*cell
            if self.target == 0:
                Color(.38, .11, .025, 1)
                RoundedRectangle(pos=(cx-cell*.32, cy-cell*.32), size=(cell*.64, cell*.68), radius=[dp(4)])
                Color(.7, .42, .08, 1)
                Rectangle(pos=(cx-cell*.13, cy+cell*.27), size=(cell*.26, cell*.25))
                Color(.95, .75, .2, 1)
                Rectangle(pos=(cx-cell*.24, cy-cell*.13), size=(cell*.48, cell*.23))
                Color(.08, .025, .02, 1)
                Rectangle(pos=(cx-cell*.18, cy-cell*.09), size=(cell*.36, cell*.15))
            else:
                Color(.52, .1, .78, 1)
                for dx, dy in [(-.2,.15),(0,.2),(.2,.15),(-.25,-.05),(-.05,0),(.16,-.03),(-.14,-.22),(.08,-.23)]:
                    Ellipse(pos=(cx+dx*cell-cell*.14, cy+dy*cell-cell*.14), size=(cell*.28,cell*.28))
                Color(.25,.8,.2,1)
                Line(points=[cx,cy+cell*.25,cx+cell*.18,cy+cell*.42],width=2)
            for i, (sx, sy) in enumerate(reversed(self.snake[1:])):
                Color(.05, .42 + .25*(i/max(1,len(self.snake))), .16, 1)
                Ellipse(pos=(ox+sx*cell+cell*.06, oy+sy*cell+cell*.06), size=(cell*.88,cell*.88))
            hx, hy = self.snake[0]
            px, py = ox+hx*cell, oy+hy*cell
            if self.face:
                Color(1,1,1,1)
                Rectangle(texture=self.face, pos=(px-cell*.18,py-cell*.18),size=(cell*1.36,cell*1.36))
            else:
                Color(.1,.9,.25,1)
                Ellipse(pos=(px,py),size=(cell,cell))

class GobiSnakeApp(App):
    def build(self):
        self.title = "Gobi Snake"
        root = BoxLayout(orientation="vertical", padding=dp(7), spacing=dp(5))
        header = BoxLayout(size_hint_y=None,height=dp(42))
        self.score = Label(text="GOBI SNAKE | Score: 0",bold=True,color=(1,.85,.2,1))
        self.target = Label(text="OLD MONK",bold=True,color=(1,.45,.6,1))
        self.high = Label(text="High: 0")
        header.add_widget(self.score); header.add_widget(self.target); header.add_widget(self.high)
        root.add_widget(header)
        self.board = Board()
        root.add_widget(self.board)
        self.status = Label(text="Your face is the snake head!",size_hint_y=None,height=dp(28))
        root.add_widget(self.status)
        controls = BoxLayout(orientation="vertical",size_hint_y=None,height=dp(142),spacing=dp(4))
        row = BoxLayout(spacing=dp(5))
        row.add_widget(Widget()); row.add_widget(self.btn("▲",lambda *_:self.board.turn((0,1)))); row.add_widget(Widget())
        controls.add_widget(row)
        row = BoxLayout(spacing=dp(5))
        row.add_widget(self.btn("◀",lambda *_:self.board.turn((-1,0))))
        row.add_widget(self.btn("▼",lambda *_:self.board.turn((0,-1))))
        row.add_widget(self.btn("▶",lambda *_:self.board.turn((1,0))))
        controls.add_widget(row)
        row = BoxLayout(spacing=dp(5))
        row.add_widget(self.btn("PLAY / RESTART",self.board.start))
        row.add_widget(self.btn("PAUSE",self.board.pause))
        controls.add_widget(row)
        root.add_widget(controls)
        Clock.schedule_interval(self.refresh, .2)
        return root

    def btn(self, text, fn):
        b=Button(text=text,bold=True,font_size="17sp",background_normal="",background_color=(.27,.07,.48,1))
        b.bind(on_release=fn)
        return b

    def refresh(self, dt):
        b=self.board
        self.score.text="GOBI SNAKE | Score: %d" % b.score
        self.target.text="🍇 GRAPES" if b.target else "🍾 OLD MONK"
        self.high.text="High: %d" % b.high
        self.status.text=b.message

if __name__ == "__main__":
    GobiSnakeApp().run()
